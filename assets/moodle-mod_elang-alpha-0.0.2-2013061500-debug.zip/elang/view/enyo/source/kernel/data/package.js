enyo.depends(
	"Model.js",
	"Collection.js",
	"ModelController.js"
);