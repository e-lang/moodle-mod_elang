(function (enyo) {


	enyo.kind({

		// ...........................
		// PUBLIC PROPERTIES

		//*@public
		name: "enyo.Source",

		//*@public
		kind: "enyo.Component",

		// ...........................
		// PROTECTED PROPERTIES

		// ...........................
		// COMPUTED PROPERTIES

		// ...........................
		// PUBLIC METHODS

		fetch: function () {

		},

		push: function () {

		},


		// ...........................
		// PROTECTED METHODS

		// ...........................
		// OBSERVERS

	});


})(enyo);