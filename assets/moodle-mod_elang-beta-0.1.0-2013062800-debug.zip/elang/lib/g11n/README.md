g11n
====

Globalization + Localization library