enyo.depends(
	"Store.js",
	"Source.js",
	"Model.js",
	"Collection.js",
	"ModelController.js"
);