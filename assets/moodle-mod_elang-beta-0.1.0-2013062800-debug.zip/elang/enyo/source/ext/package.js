enyo.depends(
	"macroize.js",
	"InputBinding.js",
	"BooleanBinding.js",
	"BooleanOnlyBinding.js"
);
