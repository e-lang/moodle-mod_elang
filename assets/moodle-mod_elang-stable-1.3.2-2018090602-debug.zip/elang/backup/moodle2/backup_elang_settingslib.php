<?php

/**
 * elang setting libs. An useless file actually.
 *
 * @package     mod
 * @subpackage  elang
 * @copyright   2013-2018 University of La Rochelle, France
 * @license     http://www.cecill.info/licences/Licence_CeCILL-B_V1-en.html CeCILL-B license
 *
 * @since       1.1.0
 */
defined('MOODLE_INTERNAL') || die;
